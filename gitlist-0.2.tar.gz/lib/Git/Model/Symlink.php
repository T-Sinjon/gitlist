<?php

namespace Git\Model;

use Git\Client;
use Git\Repository;
use Git\ScopeAware;

class Symlink
{
    protected $mode;
    protected $name;
    protected $path;

    public function getMode()
    {
        return $this->mode;
    }

    public function setMode($mode)
    {
        $this->mode = $mode;
    }

    public function getName()
    {
        return $this->name;
    }

    public function setName($name)
    {
        $this->name = $name;
    }

    public function getPath()
    {
        return $this->path;
    }

    public function setPath($path)
    {
        $this->path = $path;
    }
}